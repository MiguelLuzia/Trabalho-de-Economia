import React from 'react';
import { Euro, Coins, TrendingUp, ShoppingCart } from 'lucide-react';

function Concepts() {
  const concepts = [
    {
      icon: <ShoppingCart className="h-8 w-8 text-blue-600" />,
      title: 'Distribuição e Comércio',
      description: 'Como produtos e serviços chegam aos consumidores através de trocas comerciais.'
    },
    {
      icon: <Coins className="h-8 w-8 text-blue-600" />,
      title: 'Moeda e Funções',
      description: 'O papel da moeda como meio de troca, reserva de valor e unidade de conta.'
    },
    {
      icon: <Euro className="h-8 w-8 text-blue-600" />,
      title: 'Euro',
      description: 'A moeda única europeia e seu impacto na economia portuguesa.'
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-blue-600" />,
      title: 'Inflação',
      description: 'Como a variação dos preços afeta o poder de compra e a economia.'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">
        Conceitos Económicos Fundamentais
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {concepts.map((concept, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-4">
              {concept.icon}
              <h2 className="text-xl font-semibold ml-3">{concept.title}</h2>
            </div>
            <p className="text-gray-600">{concept.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Concepts;