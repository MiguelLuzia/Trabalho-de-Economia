import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          Economia no Nosso Dia a Dia
        </h1>
        <p className="text-lg text-gray-600">
          Descubra como os conceitos económicos moldam o mundo à nossa volta e influenciam nossas decisões diárias.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
          <img
            src="https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&q=80&w=800"
            alt="Economia"
            className="w-full h-48 object-cover rounded-md mb-4"
          />
          <h2 className="text-xl font-semibold mb-2">Aprenda Conceitos Fundamentais</h2>
          <p className="text-gray-600 mb-4">
            Da moeda à inflação, entenda os pilares da economia moderna.
          </p>
          <Link to="/conceitos" className="text-blue-600 flex items-center hover:text-blue-700">
            Explorar conceitos <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
          <img
            src="https://images.unsplash.com/photo-1434626881859-194d67b2b86f?auto=format&fit=crop&q=80&w=800"
            alt="Atividades"
            className="w-full h-48 object-cover rounded-md mb-4"
          />
          <h2 className="text-xl font-semibold mb-2">Pratique o Conhecimento</h2>
          <p className="text-gray-600 mb-4">
            Teste sua compreensão com exercícios interativos.
          </p>
          <Link to="/atividades" className="text-blue-600 flex items-center hover:text-blue-700">
            Começar atividades <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Home;