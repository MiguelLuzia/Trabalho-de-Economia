import React from 'react';
import { Calendar, CheckSquare } from 'lucide-react';

function About() {
  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">
        Sobre o Trabalho
      </h1>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Objetivo</h2>
        <p className="text-gray-600 mb-6">
          Este trabalho visa apresentar os conceitos fundamentais de economia aos alunos do 10º ano de forma clara e interativa.
        </p>

        <div className="border-t pt-6">
          <div className="flex items-center mb-4">
            <Calendar className="h-5 w-5 text-blue-600 mr-2" />
            <h3 className="font-medium">Datas Importantes</h3>
          </div>
          <ul className="space-y-2 text-gray-600">
            <li>Entrega Final: 15 de Dezembro de 2024</li>
            <li>Apresentação: 20 de Dezembro de 2024</li>
          </ul>
        </div>

        <div className="border-t pt-6 mt-6">
          <div className="flex items-center mb-4">
            <CheckSquare className="h-5 w-5 text-blue-600 mr-2" />
            <h3 className="font-medium">Critérios de Avaliação</h3>
          </div>
          <ul className="space-y-2 text-gray-600">
            <li>Compreensão dos conceitos</li>
            <li>Clareza na apresentação</li>
            <li>Participação nas atividades</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default About;