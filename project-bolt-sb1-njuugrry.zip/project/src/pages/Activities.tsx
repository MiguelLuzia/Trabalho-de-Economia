import React, { useState } from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

function Activities() {
  const [answers, setAnswers] = useState<{[key: string]: string}>({});
  const [showResults, setShowResults] = useState(false);

  const questions = [
    {
      id: 'q1',
      question: 'Qual é a principal função da moeda?',
      options: ['Meio de troca', 'Decoração', 'Coleção', 'Investimento'],
      correct: 'Meio de troca'
    },
    {
      id: 'q2',
      question: 'O que é inflação?',
      options: ['Aumento geral dos preços', 'Diminuição dos preços', 'Aumento do PIB', 'Crescimento populacional'],
      correct: 'Aumento geral dos preços'
    }
  ];

  const handleAnswer = (questionId: string, answer: string) => {
    setAnswers(prev => ({...prev, [questionId]: answer}));
  };

  const checkAnswers = () => {
    setShowResults(true);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">
        Teste Seus Conhecimentos
      </h1>

      <div className="space-y-8">
        {questions.map((q) => (
          <div key={q.id} className="bg-white rounded-lg shadow-md p-6">
            <p className="text-lg font-medium mb-4">{q.question}</p>
            <div className="space-y-2">
              {q.options.map((option) => (
                <label key={option} className="flex items-center space-x-3 p-2 rounded hover:bg-gray-50">
                  <input
                    type="radio"
                    name={q.id}
                    value={option}
                    onChange={() => handleAnswer(q.id, option)}
                    className="h-4 w-4 text-blue-600"
                  />
                  <span className="text-gray-700">{option}</span>
                  {showResults && answers[q.id] === option && (
                    option === q.correct ? 
                      <CheckCircle className="h-5 w-5 text-green-500" /> :
                      <XCircle className="h-5 w-5 text-red-500" />
                  )}
                </label>
              ))}
            </div>
          </div>
        ))}

        <button
          onClick={checkAnswers}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
        >
          Verificar Respostas
        </button>
      </div>
    </div>
  );
}

export default Activities;